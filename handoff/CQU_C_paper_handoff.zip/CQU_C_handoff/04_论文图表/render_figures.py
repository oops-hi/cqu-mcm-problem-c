import csv
from collections import defaultdict
from pathlib import Path

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.ticker import FuncFormatter, MultipleLocator, PercentFormatter
import numpy as np

package = Path(__file__).resolve().parents[1]
out = package/'04_论文图表'
results = package/'03_结果'

def read(name):
    with (results/name).open(encoding='utf-8-sig', newline='') as fp:
        return list(csv.DictReader(fp))

navy, teal, coral, grey = '#274760', '#187D73', '#CA694C', '#8190A1'
plt.rcParams.update({'font.family':'DejaVu Sans', 'font.size':10, 'axes.spines.top':False,
                     'axes.spines.right':False, 'axes.labelcolor':'#263744',
                     'xtick.color':'#263744','ytick.color':'#263744','text.color':'#172B3A',
                     'axes.titleweight':'bold', 'svg.fonttype':'none', 'pdf.fonttype':42})

def finish(fig, stem):
    for extension in ('png','pdf','svg'):
        fig.savefig(out/f'{stem}.{extension}', dpi=300, facecolor='white')
    plt.close(fig)

orders = defaultdict(lambda: [0.0,0.0])
for row in read('departure_forecasts.csv'):
    key = row['date'], int(row['minute'])//60
    orders[key][0] += int(row['observed_departures'])
    orders[key][1] += float(row['forecast_departures'])
fig, axes = plt.subplots(1,3,figsize=(12,3.6),sharey=True,layout='constrained')
for ix, (ax, day) in enumerate(zip(axes, ['2017-05-19','2017-05-21','2017-05-22'])):
    actual, expected = np.array([orders[day,h] for h in range(24)]).T
    ax.plot(np.arange(24),actual,color=navy,linewidth=2,label='Recorded')
    ax.plot(np.arange(24),expected,color=coral,linewidth=2,linestyle='--',label='Forecast')
    ax.set(title=['May 19 | Weekday','May 21 | Weekend','May 22 | Low records'][ix],
           xlabel='Hour of day',xlim=(0,23),ylim=(0,35000))
    ax.set_xticks([0,6,12,18,23])
    ax.grid(axis='y',alpha=.20)
    ax.yaxis.set_major_formatter(FuncFormatter(lambda x,_:f'{x/1000:g}k'))
    if ix==0:
        ax.legend(frameon=False,loc='upper left')
axes[0].set_ylabel('Hourly ride departures')
finish(fig,'Fig01_Held_out_departures')

metrics = {r['scenario']:r for r in read('policy_comparison.csv')}
methods = [
    ('Greedy', 'greedy', grey),
    ('Rolling · economy', 'rolling', navy),
    ('Rolling · service', 'rolling_service', teal),
    ('Greedy + reward', 'greedy_dynamic_cap100', grey),
    ('Rolling + reward', 'rolling_service_dynamic_cap100', teal),
]
fig, axes = plt.subplots(1,2,figsize=(10.5,4.0),sharey=True,layout='constrained',
                         gridspec_kw={'width_ratios':[1.1,1.0]})
y=np.arange(len(methods))
for ax, col, title, xlim in zip(axes,['simulated_missed','estimated_truck_km'],
                               ['Simulated unserved orders','Estimated truck distance (km)'],[405,2300]):
    vals=[float(metrics[key][col]) for _,key,_ in methods]
    bars=ax.barh(y,vals,height=.62,color=[c for _,_,c in methods])
    ax.bar_label(bars,labels=[f'{v:,.0f}' for v in vals],padding=5,fontsize=9)
    ax.set(xlabel=title,xlim=(0,xlim))
    ax.grid(axis='x',alpha=.2)
    ax.set_axisbelow(True)
axes[0].set_yticks(y,[name for name,_,_ in methods])
axes[0].invert_yaxis()
fig.suptitle('Rebalancing and reward replay across three held-out days',fontweight='bold')
finish(fig,'Fig02_Dispatch_tradeoff')

fence={(r['pilot_zone'], r['date_or_profile'], r['layout']):float(r['mobike_uncovered_or_overflow_bike_hour_rate'])
       for r in read('fence_evaluation.csv') if r['competitor_relative_load']=='0.0'}
pilots=['wx4f9m','wx4ff1','wx4f8m']
modes=[('Popular points, equal capacity','popular_equal',grey),('Weekday-only','optimized',coral),
       ('Weekday + weekend','multi_scenario',teal)]
fig, axes=plt.subplots(1,2,figsize=(10.7,4.1),sharey=True,layout='constrained')
for panel,day,caption in zip(axes,['2017-05-19','2017-05-21'],['May 19 | Weekday','May 21 | Weekend']):
    for n, (name, mode, color) in enumerate(modes):
        panel.bar(np.arange(3)+(n-1)*.24,[fence[p,day,mode] for p in pilots],width=.22,color=color,label=name)
    panel.set_xticks(np.arange(3),pilots)
    panel.set(title=caption,xlabel='Pilot zone',ylim=(0,.40))
    panel.yaxis.set_major_formatter(PercentFormatter(xmax=1,decimals=0))
    panel.yaxis.set_major_locator(MultipleLocator(.1))
    panel.grid(axis='y',alpha=.20)
    panel.set_axisbelow(True)
axes[0].set_ylabel('Uncovered or overflow bike-hours (%)')
axes[1].legend(frameon=False,fontsize=8,loc='upper right')
finish(fig,'Fig03_Geofence_validation')
print('Wrote three paper figures as PNG, PDF and SVG')
