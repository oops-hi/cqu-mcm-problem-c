图 1 至 3 提供 PNG、PDF 与 SVG。图 4 为围栏试点的 PNG。
在源码 Conda 环境中运行本目录的 render_figures.py 可从包内 CSV 重绘图 1 至 3。
图注建议见上一级《公式与写作素材》。
